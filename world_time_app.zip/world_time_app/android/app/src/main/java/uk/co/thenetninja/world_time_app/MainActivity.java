package uk.co.thenetninja.world_time_app;

import androidx.annotation.NoNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import android.os.Bundle;
import io.flutter.app.FlutterActivity;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity extends FlutterActivity {
  @Override
  public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
    protected void onCreate (Bundle savedInstanceState){
      super.onCreate(savedInstanceState);
      GeneratedPluginRegistrant.registerWith(this);
    }
  }
}
